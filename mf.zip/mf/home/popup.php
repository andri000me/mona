<?php
?>
<!-- ===================================MODAL AKSES DITUTUP=============================== -->
<div class="modal fade" id="modalAksesDitutup" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="text-center">
            <h3 class="font-popup-disablehakakses">Sorry, akses tidak dapat dibuka...</h3>
            <img src="../src/img/pusing.png" style="width:200px">
        </div>
    </div>
</div>


<!-- ===================================MODAL MENGERJAKAN PART============================ -->
<div class="modal fade" id="mengerjakanPart" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title font-popup-enablehakakses">Tata Cara Mengerjakan MATHFOSTER part#1</h5>
            </div>
            <div class="modal-body">
                <p>Terdapatlah seorang brahmana bernama Somasarma yang tinggal di
                    sebuah tirtha (tempat suci) yang bernama Vamana tirtha di pinggir
                    Sungai Reva. Istrinya bernama Sumana. Somasarma dan Sumana
                    adalah pasangan yang miskin. Mereka juga tidak memiliki seorang
                    anakpun. Inilah yang membuat Somasarma selau sedih. Sumana
                    kemudian menyarankan suaminya meminta nasehat Rsi Vasistha.
                    Barangkali sang rsi bisa membantu agar mereka bisa memiliki
                    seorang putra.
                    Somasarma kemudian pergi ke pertapaan Rsi Vasistha. “Mengapa
                    hamba ini miskin dan mengapa hama tidak memiliki seorang
                    putrapun?” demikian pertanyaannya.
                    “Kau miskin karena dosa-dosa yang kau lakukan di masa yang lalu”
                    jawab sang rsi”. Aku akan menceritakannya padamu.</p>
            </div>
            <div class="modal-footer">
                <input type="button" value="Mengerti !!!.." class="lanjutkan" data-dismiss="modal">
            </div>
        </div>
    </div>
    <!-- <div class="modal-dialog" role="document">
        <div class="modal-header">
            <h5>Modal title</h5>
        </div>
        <div class="modal-body">
            <p>Modal body text goes here.</p>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary">Save changes</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        <div class="text-center">
            <img src="http://kelasbos.com/wp-content/uploads/2018/08/semangat.png" style="width:200px">
            <h3 class="font-popup-enablehakakses">Semangat untuk mengerjakannya ....</h3>
            <input type="button" value="Mengerti !!!.." class="lanjutkan" data-dismiss="modal">
        </div>
    </div> -->
</div>


<!-- ===================================MODAL SELESAI MENGERJAKAN========================== -->
<div class="modal fade" id="selesaiPart" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="text-center">
            <h3 class="font-popup-enablehakakses">Selamat Kamu Telah Lulus Part ...</h3>
            <img src="https://cdn.pixabay.com/photo/2016/02/07/14/50/im-happy-1184894_960_720.png" style="width:300px">
            <img src="http://www.sclance.com/pngs/100-png/100_png_1112.png" style="width:100px">
            <!-- <a href="#" class="lanjutkan">Lanjutkan..</a> -->
            <br>
            <a href="matfoster.php"><button type="submit" class="lanjutkan">Lanjutkan</button></a>
            <!-- <input type="button" value="Lanjut Part..." class="lanjutkan"> -->
        </div>
    </div>
</div>