<?php
    include "header.php";
    include "popup.php"
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="images/favicon.ico" type="image/ico" />

    <title>Gentelella Alela! | </title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <!-- disable new tab -->
    <script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js'></script>
</head>

<body>
    <div class="container margin-kanan-kiri">
        <div class="row">
            <div class="col-md-11"><label style="font-size: 20px">MATHFOSTER PART 1</label></div>
            <div class="col-md-1"><label style="font-size: 20px" id="timer">Waktu</label></div>
        </div>
        <div class="row">
            <div id="wizard" class="form_wizard wizard_horizontal">

                <!-- ==================START DEKLARASI NOMOR================== -->
                <!-- ==================Merubah Wizardnya ada di JS-nya yaa================== -->
                <ul class="wizard_steps">
                    <?php
                for ($i=1; $i<=5; $i++){
                    ?>
                    <li>
                        <a href="#step-<?php echo $i; ?>">
                            <span class="step_no"><?php echo $i; ?></span>
                            <!-- <span class="step_descr">
                        Step <?php //echo $i; ?><br />
                    </span> -->
                        </a>
                    </li>
                    <?php
                }
             ?>
                </ul>
                <!-- ==================END DEKLARASI NOMOR================== -->

                <!-- ==================TAMPIL SOAL DAN INPUT JAWABAN================== -->
                <?php
                for ($i=1; $i<=5; $i++){
                    ?>
                <div id="step-<?php echo $i; ?>">
                    <form class="form-horizontal form-label-left">
                        <div class="form-group">
                            <div style="margin-left: 10px">
                                <div class="container">
                                    <h2>Soal Nomor <?php echo $i; ?></h2>
                                    <p>The form below contains a textarea for comments:</p>
                                    <div class="form-group">
                                        <label for="comment">Jawabanmu:</label>
                                        <!-- <textarea class="form-control" rows="3" id="jawabanSiswa-<?php echo $i; ?>"></textarea> -->
                                        <textarea class="form-control" rows="3" id="jawabanSiswa"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <?php
                }
             ?>
            </div>
        </div>
    </div>





    <!-- ===================== KOMPONEN BOOTSTRAP =================== -->
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- HORIZONTAL SCROLLING -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.min.js'></script>
    <script src="../build/js/horizontalscrolling.js"></script>

    <!-- jQuery Smart Wizard -->
    <script src="../vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script>


    <script>
    function popupMengerjakan() {
        $("#mengerjakanPart").modal();
    }
    </script>

    <script>
    setInterval(cekSwitchTabs, 1);
    var count = 0;

    function cekSwitchTabs() {
        if (!document.hasFocus()) {
            // alert("ccccccccccccccccccccccccccccccccccccccccc");
            // console.log("ok");
        } else {
            // console.log(count)
        }
    }
    </script>

    <!-- menghitung timer -->
    <script>
    setInterval(timer, 1000);
    var s = 0;

    function timer() {
        s++;
        var jam = s / 3600;
        var sisa = s % 3600;
        var menit = sisa / 60;
        var detik = sisa % 60;
        document.getElementById("timer").innerHTML = Math.floor(jam) + " : " + Math.floor(menit) + " : " + detik;
    }
    </script>
</body>

</html>