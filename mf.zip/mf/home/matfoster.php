<?php
    include "header.php";
    include "popup.php"
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- COLLAPSED -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="icon" href="images/favicon.ico" type="image/ico" />

    <title>Gentelella Alela! | </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">

    <!-- HORIZONTAL SCROLLING -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/css/swiper.css'>
    <link rel="stylesheet" href="../build/css/horizontalscrolling.css">
</head>

<body>
    <div class="container margin-kanan-kiri">
        <!-- <form action="mengerjakan.php" method="POST"> -->
        <div class="white-box col-md-12 " data-url="#" id="cardTaskMf">
            <div class="card--style-1__judul margin-kanan-kiri">
                <h3><b>MathFoster Part 1</b></h3>
            </div>
            <div class="imgs-">
                <img style="float:right;margin-top: -4%;" src="https://bajo.jumbomark.com/labels/J002018033326" alt=""
                    class="icon">
            </div>
            <h5 style="text-align:justify; line-height: 2;">Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi
                nya.
                Deskripsi nya. Deskripsi nya.
                Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi
                nya.
                Deskripsi nya. Deskripsi nya.
                Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi
                nya.
                Deskripsi nya. Deskripsi nya.
                Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi
                nya.
                Deskripsi nya. Deskripsi nya. Deskripsi nya.
                Deskripsi nya. Deskripsi nya. Deskripsi nya. Deskripsi nya.. </h5>
            <button type="submit" class="btn btn-info" name="submit" data-toggle="modal"
                data-target="#mengerjakanParts">Mulai Mengerjakan</button>
        </div>
        <!-- </form> -->
    </div>

    <div class="container margin-kanan-kiri">
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <?php
          $akses=false;
          for ($x = 2; $x <= 10; $x++) {
          ?>
                <div class="swiper-slide">
                    <!-- box part -->
                    <div class="container">
                        <div class="row">
                            <div class="animated flipInY">
                                <div class="tile-stats">

                                    <!-- valdasi icon jika telah selesai part sebelumnya -->
                                    <?php
                    if ($akses && $x==2) {
                      ?>
                                    <div class="icon" style="margin-top: 20px"><i class="fa fa-unlock"></i></div>
                                    <div>Part <?php echo $x; ?></div>
                                    <a href="#" class="btn btn-success" data-effect="mfp-zoom-in">Mulai Mengerjakan</a>
                                    <p>Jangan Lupa Berdoa</p>
                                    <?php
                    } else {
                      ?>
                                    <div class="icon" style="margin-top: 20px"><i class="fa fa-lock"></i></div>
                                    <div>Part <?php echo $x; ?></div>
                                    <a href="#" class="btn btn-danger" data-effect="mfp-zoom-in" data-toggle="modal"
                                        data-target="#modalAksesDitutup">Akses Di Tutup</a>
                                    <p>Maaf kamu belum diperbolehkan mengerjakan part ini</p>
                                    <?php
                    }                    
                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end box part -->
                </div>
                <?php
          }
          ?>
            </div>
        </div>

        <!-- TABEL HISTORI MENGERJAKAN -->
        <div class="row" style="margin-top:10px">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel" style="border-radius: 20px">
                    <div class="x_title">
                        <a class="collapse-link">
                            <h2>Histori Pengerjaanmu</h2></i>
                        </a>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content" style="display:none">
                        <table id="datatable" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>------</th>
                                    <th>------</th>
                                    <th>------</th>
                                    <th>------</th>
                                    <th>------</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>


                            <tbody>
                                <tr>
                                    <td>*************</td>
                                    <td>*************</td>
                                    <td>*************</td>
                                    <td>*************</td>
                                    <td>*************</td>
                                    <td>
                                        <button Type="submit" class="btn btn-info" data-toggle="modal"
                                            data-target="#selesaiPart">
                                            Detail
                                            <span class="badge bg-red">10</span>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- end dari div container -->


    <!-- ===================================MODAL MENGERJAKAN PART============================ -->
    <div class="modal fade" id="mengerjakanParts" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="mengerjakan.php" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title font-popup-enablehakakses">Tata Cara Mengerjakan MATHFOSTER part#1</h5>
                    </div>
                    <div class="modal-body">
                        <p>Terdapatlah seorang brahmana bernama Somasarma yang tinggal di
                            sebuah tirtha (tempat suci) yang bernama Vamana tirtha di pinggir
                            Sungai Reva. Istrinya bernama Sumana. Somasarma dan Sumana
                            adalah pasangan yang miskin. Mereka juga tidak memiliki seorang
                            anakpun. Inilah yang membuat Somasarma selau sedih. Sumana
                            kemudian menyarankan suaminya meminta nasehat Rsi Vasistha.
                            Barangkali sang rsi bisa membantu agar mereka bisa memiliki
                            seorang putra.
                            Somasarma kemudian pergi ke pertapaan Rsi Vasistha. “Mengapa
                            hamba ini miskin dan mengapa hama tidak memiliki seorang
                            putrapun?” demikian pertanyaannya.
                            “Kau miskin karena dosa-dosa yang kau lakukan di masa yang lalu”
                            jawab sang rsi”. Aku akan menceritakannya padamu.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-info" name="submit">Mulai Mengerjakan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>





    <!-- ===================== KOMPONEN BOOTSTRAP =================== -->
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

    <!-- HORIZONTAL SCROLLING -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.min.js'></script>
    <script src="../build/js/horizontalscrolling.js"></script>


    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

</body>

</html>